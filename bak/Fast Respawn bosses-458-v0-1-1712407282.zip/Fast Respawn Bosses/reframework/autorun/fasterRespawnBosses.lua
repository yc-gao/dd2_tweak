local isBoss
local isDungeon
local value = 0


sdk.hook(
    sdk.find_type_definition("app.GenerateDefaultParameter"):get_method("getDeadCharaRepopTime(System.Boolean, System.Boolean)"),
function (args)
    isBoss = (sdk.to_int64(args[3]) & 1) == 1
    isDungeon = (sdk.to_int64(args[4] ) & 1) == 1
end,
function (postargs)
    local time = sdk.to_int64(postargs)
    log.debug("isBoss ".. tostring(isBoss).." isDungeon ".. tostring(isDungeon).." Repop Time: "..tostring(time))
    if isBoss then
        log.debug("Set Boss Time from "..tostring(time).." to 0")
       return sdk.to_ptr(0)
    end
    return postargs
end)