local re = re
local sdk = sdk
local log = log
local json = json
local hotkeys = require("Hotkeys/Hotkeys")

log.info("[HCL Levitation] Loaded");

local Config = {}

Config.Hotkeys = {
	["Input Key"] = "Space",    
	["End Key"] = "E",  
	["Jump Key"] = "LShift",  
	["Stop Key"] = "LControl",  
}

local configFilePath = "HCL_Levitation.json"
hotkeys.setup_hotkeys(Config.Hotkeys)

function saveConfig()
    local success, err = pcall(json.dump_file, configFilePath, Config)
    if not success then
        log.error("Error saving configuration: " .. tostring(err))
    end
end

function loadConfig()
    local status, data = pcall(json.load_file, configFilePath)
    if not status or not data then
        return
    end
    if type(data) == "table" then
		if data.Hotkeys then
			Config.Hotkeys = data.Hotkeys
			hotkeys.setup_hotkeys(Config.Hotkeys)
		end
    end
end

loadConfig()
local InputState = {
    ["None"] = 0,
    ["LevitateStart"] = 1,
    ["LevitateKeep"] = 2,
    ["LevitateEnd"] = 3,
}
local currentState = InputState["None"]

function getPlayer()
	local cm = sdk.get_managed_singleton("app.CharacterManager")
	local player = cm:get_ManualPlayer()
	return player
end

local function generate_enum(typename)
    local t = sdk.find_type_definition(typename)
    if not t then return {} end
    local fields = t:get_fields()
    local enum = {}
    for i, field in ipairs(fields) do
        if field:is_static() then
            local name = field:get_name()
            local raw_value = field:get_data(nil)

            enum[name] = raw_value
        end
    end
    return enum
end

local UpDownModeEnum = generate_enum("app.LevitateController.UpDownModeEnum")
local IDEnum = generate_enum("app.CharacterID")
local set_node_method = sdk.find_type_definition("via.motion.MotionFsm2Layer"):get_method("setCurrentNode(System.String, via.behaviortree.SetNodeInfo, via.motion.SetMotionTransitionInfo)")
local pIP = nil

sdk.hook(
    sdk.find_type_definition("app.PlayerInputProcessor"):get_method("processMove()"),
    function(args)
        pIP = sdk.to_managed_object(args[2])
    end,
    function(rtVal)
        if pIP ~= nil then
               local chara = pIP:get_Chara()
               if chara:get_CharaID() == IDEnum["ch000000_00"] and (currentState == InputState["LevitateStart"] or currentState == InputState["LevitateKeep"]) then
                    local job03Detail = pIP.DetailInstances[2]
                    sdk.call_object_func(job03Detail, "processMoveSpecial")
               end
        end
        return rtVal
    end
)

local setn = ValueType.new(sdk.find_type_definition("via.behaviortree.SetNodeInfo"))
setn:call("set_Fullname", true)
local interper = sdk.create_instance("via.motion.SetMotionTransitionInfo"):add_ref()
interper:set_InterpolationFrame(20.0)

local player = nil
local notInGroundFrameCounter = 0
local levitateKeyPressingCounter = 0
local EndKeyPressingCounter = 0
local GoingtoFly = 0

re.on_application_entry("LateUpdateBehavior", function()
		player = getPlayer()

		if player ~= nil then
			if not player:get_IsGround() then
				if notInGroundFrameCounter < 100 then
					notInGroundFrameCounter = notInGroundFrameCounter + 1
				else
					notInGroundFrameCounter = 100
				end
			else
				currentState = InputState["None"]
				notInGroundFrameCounter = 0
			end

			local CanFly = true
			if hotkeys.check_hotkey("Stop Key", true, false) then
				CanFly = false
			end

			if notInGroundFrameCounter > 5 then
				local human = player:get_Human()
				local levitate = human:get_LevitateCtrl()
				local UseInfiniteJump = false
				if hotkeys.check_hotkey("Jump Key", true, false) then
					UseInfiniteJump = true
				end 

				if GoingtoFly > 7 then
					currentState = InputState["LevitateStart"]
					local gameobj = player:get_GameObject()
					local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
					set_node_method:call(mfsm2:getLayer(0), "JobMagicUser.JobMagicUser_StartLevitate", setn, interper)
					GoingtoFly = 7
				elseif GoingtoFly == 7 then
						GoingtoFly = 6
				elseif GoingtoFly == 6 then
					if currentState == InputState["LevitateStart"] then
						levitate.UpDownMode = UpDownModeEnum["Keep"]
						currentState = InputState["LevitateKeep"]
					end
					GoingtoFly = 5
				elseif GoingtoFly == 5 then
						GoingtoFly = 4
				elseif GoingtoFly == 4 then
					local gameobj = player:get_GameObject()
					local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
					local setn = ValueType.new(sdk.find_type_definition("via.behaviortree.SetNodeInfo"))
					setn:call("set_Fullname", true)
					local interper = sdk.create_instance("via.motion.SetMotionTransitionInfo"):add_ref()
					interper:set_InterpolationFrame(20.0)
					set_node_method:call(mfsm2:getLayer(0), "Job04.Job04_SkillAttack.Job04_CS10.Job04_WindWaveAir", setn, interper)
					GoingtoFly = 0
				elseif GoingtoFly == 3 then
					if currentState == InputState["LevitateStart"] then
						levitate.UpDownMode = UpDownModeEnum["Keep"]
						currentState = InputState["LevitateKeep"]
						GoingtoFly = 2
					else
						GoingtoFly = 0
					end
				elseif GoingtoFly == 2 then
						GoingtoFly = 1
				elseif GoingtoFly == 1 then
					if hotkeys.check_hotkey("Input Key", true, false) then
						currentState = InputState["LevitateStart"]
						local gameobj = player:get_GameObject()
						local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
						set_node_method:call(mfsm2:getLayer(0), "JobMagicUser.JobMagicUser_StartLevitate", setn, interper)
					end 
					GoingtoFly = 0
				end 

				if not levitate:get_IsActive() and GoingtoFly == 0 and UseInfiniteJump and hotkeys.check_hotkey("Input Key", false, true) then
					if notInGroundFrameCounter > 15 then
						GoingtoFly = 8
					else
						local gameobj = player:get_GameObject()
						local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
						local setn = ValueType.new(sdk.find_type_definition("via.behaviortree.SetNodeInfo"))
						setn:call("set_Fullname", true)
						local interper = sdk.create_instance("via.motion.SetMotionTransitionInfo"):add_ref()
						interper:set_InterpolationFrame(20.0)
						set_node_method:call(mfsm2:getLayer(0), "Job04.Job04_SkillAttack.Job04_CS10.Job04_WindWaveAir", setn, interper)
					end				
				else
					if hotkeys.check_hotkey("Input Key", true, false) then
						if levitateKeyPressingCounter > 0 and UseInfiniteJump then
							levitateKeyPressingCounter = 0
						elseif levitateKeyPressingCounter < 100 then
							levitateKeyPressingCounter = levitateKeyPressingCounter + 1
						else
							levitateKeyPressingCounter = 100
						end
					else
						levitateKeyPressingCounter = 0
					end

					if levitateKeyPressingCounter > 5 and currentState == InputState["None"] and CanFly then
						currentState = InputState["LevitateStart"]
						local gameobj = player:get_GameObject()
						local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
						set_node_method:call(mfsm2:getLayer(0), "JobMagicUser.JobMagicUser_StartLevitate", setn, interper)
						if notInGroundFrameCounter > 15 then
							GoingtoFly = 3
						end
					end

					if currentState == InputState["LevitateStart"] then
						if hotkeys.chk_up("Input Key") then
							levitate.UpDownMode = UpDownModeEnum["Keep"]
							currentState = InputState["LevitateKeep"]
							levitateKeyPressingCounter = 0
						end
					end

					if currentState == InputState["LevitateKeep"] then
						if hotkeys.check_hotkey("End Key", false, true) then
							local gameobj = player:get_GameObject()
							local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
							set_node_method:call(mfsm2:getLayer(0), "JobMagicUser.JobMagicUser_EndLevitate", setn, interper)
							currentState = InputState["None"]
							levitateKeyPressingCounter = 0
						elseif hotkeys.check_hotkey("Input Key", false, true) then
							if CanFly then
								currentState = InputState["LevitateStart"]
								local gameobj = player:get_GameObject()
								local mfsm2 = gameobj:call("getComponent(System.Type)", sdk.typeof("via.motion.MotionFsm2"))
								set_node_method:call(mfsm2:getLayer(0), "JobMagicUser.JobMagicUser_StartLevitate", setn, interper)
							end
						end
					end
				end
			end
		end
end)

re.on_draw_ui(function()
	if imgui.tree_node("HCL_Levitation") then
		local changed = false
		local changagain = false
		local changJump = false
		local changStop = false
       		local fakeName = "Start Levitation Key"
        	local endName = "End Levitation Key"
        	local JumpName = "Infinite Jump Modifier Key"
        	local StopName = "Prevent Levitation Key"

		changed = hotkeys.hotkey_setter("Input Key", false, fakeName)
		changagain = hotkeys.hotkey_setter("End Key", false, endName)
		changJump = hotkeys.hotkey_setter("Jump Key", false, JumpName)
		changStop = hotkeys.hotkey_setter("Stop Key", false, StopName)

		if changed or changagain or changJump or changStop then
        		hotkeys.update_hotkey_table(Config.Hotkeys)
			saveConfig() 
		end
		imgui.tree_pop()
	end
end
)